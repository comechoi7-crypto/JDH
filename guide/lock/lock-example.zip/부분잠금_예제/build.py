"""부분 잠금 페이지 만들기
같은 폴더의 원본.html 을 읽어 <priv>…</priv> 부분을 .pw 의 비밀번호로 암호화하고
index.html 을 만듭니다.  깃허브에는 index.html 만 올립니다.

처음 한 번:  pip install cryptography
실행:        python build.py
"""
import base64, os, re, random
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

HERE = Path(__file__).resolve().parent
PW   = (HERE / ".pw").read_text(encoding="utf-8").strip()      # ① 비밀번호 읽기
SALT = os.urandom(16)                                          # ② 임의값(공개돼도 됨)
KEY  = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32,        # ③ 비밀번호 → 열쇠
                  salt=SALT, iterations=300000).derive(PW.encode())
b64  = lambda x: base64.b64encode(x).decode()

def lock(m):                                                   # ④ <priv> 한 덩어리 잠금
    inner = m.group(1)
    iv = os.urandom(12)
    ct = AESGCM(KEY).encrypt(iv, inner.encode(), None)
    plain = re.sub(r"<[^>]+>|\s+", "", inner)
    fake = "".join(chr(0xAC00 + random.randrange(11172)) if random.random() > .15 else " "
                   for _ in range(max(30, len(plain))))
    return (f'<div class="lock" data-iv="{b64(iv)}" data-ct="{b64(ct)}">'
            f'<div class="fog" aria-hidden="true">{fake}</div>'
            f'<button type="button" class="unlock">🔒 비밀번호 입력</button></div>')

src = (HERE / "원본.html").read_text(encoding="utf-8")
src = re.sub(r"<!--.*?-->", "", src, flags=re.S)              # 주석 제거(주석 속 <priv> 오인 방지)
n   = len(re.findall(r"<priv>", src))
out = re.sub(r"<priv>(.*?)</priv>", lock, src, flags=re.S)     # ⑤ 모든 <priv> 교체
out = out.replace("{{SALT}}", b64(SALT))                       # ⑥ 임의값 심기
(HERE / "index.html").write_text(out, encoding="utf-8")
print(f"완료: index.html (잠근 부분 {n}곳)")

# 안전 점검: 비밀번호가 결과에 들어갔는지
if PW in out:
    print("⚠ 경고: 결과 파일에 비밀번호 문자열이 보입니다. 올리기 전에 확인하세요.")
